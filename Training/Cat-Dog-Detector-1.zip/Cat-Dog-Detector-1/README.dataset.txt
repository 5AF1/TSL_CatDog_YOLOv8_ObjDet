# Cat Dog Detector > 2023-04-16 12:18am
https://universe.roboflow.com/md-safirur-rashid/cat-dog-detector-nhyrj

Provided by a Roboflow user
License: CC BY 4.0

