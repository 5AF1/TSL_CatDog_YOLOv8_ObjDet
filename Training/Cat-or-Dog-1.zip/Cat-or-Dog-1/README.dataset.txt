# Cat or Dog > 2022-07-01 8:44pm
https://universe.roboflow.com/test-eama7/cat-or-dog-6dt85

Provided by a Roboflow user
License: CC BY 4.0

