# cat and dog detection > 2022-09-17 5:23pm
https://universe.roboflow.com/warda-ghafoor-4ofya/cat-and-dog-detection

Provided by a Roboflow user
License: CC BY 4.0

